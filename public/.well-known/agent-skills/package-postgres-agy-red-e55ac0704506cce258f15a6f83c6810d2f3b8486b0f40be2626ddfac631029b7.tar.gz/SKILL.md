---
name: package-postgres-agy-red
description: Build and operate a three-node PostgreSQL 17 failover cluster on DigitalOcean with Patroni, colocated etcd v3, HAProxy client routing, Cloudflare DNS, pgBackRest backups to Cloudflare R2, heartbeat streaming, and verified restore check.
license: MIT
---

# PostgreSQL 17 High Availability on DigitalOcean

Read `colors.yml` before changing desired state or running a lifecycle command.

## Safety

- Keep secrets out of `colors.yml`; use gitignored `COLORS_PAR_*` exports.
- Never set `COLORS_PAR_PROFILE` and never edit generated `.colors/` files.
- Default to `build` and `create --dry-run`; real create/delete needs explicit authorization.
- Keep `compute-prevent-destroy: true`. Lift it for one authorized delete with `COLORS_PAR_COMPUTE_PREVENT_DESTROY=false`.
- Restrict `digitalocean-ssh-sources` and `digitalocean-client-sources`; do not use `0.0.0.0/0`.

## Commands

```sh
./red build
./red create --dry-run
./red create
./red status
./red switchover
./red backup
./red verify-restore
./red psql
./red delete
```
