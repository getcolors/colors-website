# Acceptance doctrine

What each gate checks, and — more usefully — what a *weaker* version of it would
have let through. Every gate below ran on a live deployment; the implementation
lives in `getcolors/n8n`.

## Storage tier

**The tenant and timeline in desired state are the ones attached.** Fixing those
identifiers in desired state is what makes the check possible at all; a
deployment that mints them at runtime has nothing to compare against.

**Remote storage is real *and fresh*.** Pageserver object *existence* only —
layer uploads follow the checkpoint cadence, so demanding a new one per converge
flakes. But after `pg_switch_wal()` a **new** safekeeper segment must appear
beyond a pre-switch sorted baseline. Historical objects must not satisfy the WAL
gate, or a broken uploader hides behind them indefinitely.

**n8n is really on the intended database.** Not "the tables exist and there is
no SQLite file" — that can pass while the live process writes somewhere else.
Create a uniquely tagged workflow through the running instance's **API**, then
read that exact row back through a direct database connection. Separately assert
`DB_TYPE=postgresdb` in the running container: the real silent-SQLite trap is a
`DB_TYPE` typo, not a missing connection variable.

**The schema matches the pinned image.** Gate the migrations table's contents,
not a log line. Logs rotate, wording changes across versions, and a partially
applied migration still logs progress.

## Application tier

**Liveness and readiness, separately.** `/healthz` returns 200 while the
database connection is still initialising; `/healthz/readiness` is the one that
gates on the database. Collapsing them into one check is how dependents start
against an instance that cannot serve a request.

**Origin TLS from the host, origin reachability from outside.** Once the
firewall admits only the CDN, a workstation cannot reach the origin at all — so
the certificate check runs host-locally against loopback with the public SNI,
and the "origin refuses non-CDN traffic" check runs from the workstation over
both address families. One probe cannot satisfy both; they need different
vantage points.

**The generated production webhook URL, exactly.** This is what catches the
deprecated `WEBHOOK_URL` spelling: with it, n8n falls back to its own host and
port and hands third parties a URL that never resolves. Webhook URLs given to
third parties are effectively permanent, so a wrong one is not cosmetic.

**The owner account is claimed — before the public name resolves.** n8n's
first-run setup screen is unauthenticated: between the proxy serving the name
and an owner existing, whoever arrives first owns the instance and every
credential it will ever store. Claim it during convergence over the internal
network, and gate the end state. Already-claimed is success, not an error, or
the converge stops being re-runnable.

**A Code node *executes* on the runner.** Not "a runner registered" — the log
wording is not stable across versions, and a runner reports connected long
before it has run a task. That is exactly the failure mode of a runner/main
version mismatch. Only execution distinguishes a working runner from a connected
one.

**sshd rejects password and root-password authentication.** Where SSH is open to
the internet by convention, these negative controls are the entire mitigation,
so assert them rather than trusting an image default. Two notes: `sshd -T`
reports `prohibit-password` as the legacy synonym `without-password`, so a gate
matching only the modern spelling accuses a correctly hardened host; and capture
`sshd -T` **once** — invoking it per assertion lets a transient empty result
make two checks disagree about the same host in the same run.

## Load

A blocking soak with a **declared workload mix**, not a count. A bare count of
small executions meets every threshold without touching what actually breaks the
host: Code-node memory multiplication and binary-data churn. Include a
Code-node tier sized to trigger the payload duplication and a binary tier that
forces writes through the filesystem path.

Two **separately thresholded** latency measurements, because "database latency"
is otherwise whatever is easiest to report: application-role SQL round-trip
sampled independently, and end-to-end execution duration from the API. They are
different numbers and fail for different reasons.

Cleanup is part of the gate. A soak that leaves its rows behind poisons the next
run's measurements and every backup taken afterwards — and the cleanup's own
exit code is not evidence, because a DELETE that n8n refuses still returns
success per call. Assert the residue is gone.

## Retention

Qualify pruning in an **isolated scratch stack**, never against production:
declared retention is measured in hundreds of hours, and mutating it to
something observable would delete real history and violate the state being
converged. Upstream's intervals are unobservable in a drill anyway (soft-delete
hourly, hard-delete every 15 minutes) and have to be wound down.

The production gate is narrower by design: assert the **rendered** retention
values are the declared ones and that the prune workers are running.

## Restart

Two lifecycles, because they fail differently: a full `down` + `up` from
stopped, and an **unattended host reboot**. Both must return with no manual
sequencing — restart policies and health conditions only. Read the witness row
straight from the database rather than through the application, so the check
does not depend on the thing being restarted.

**A reboot drill cannot be a single in-host process**: it is killed by the very
event it is measuring. Split it into an arm phase that persists the witness and
triggers the reboot, and a check phase driven from the operator side once the
host is back.

## Recovery

Restore **both** artifacts into an isolated scratch stack — its own database and
its own data directory — boot the **pinned** image against them, and prove four
things a checksum cannot:

1. an operator can **log in** (whole-host recovery restores the database and the
   data directory but not the host's generated secrets, so a restore nobody can
   sign into is not a recovery)
2. the workflow rows are present
3. a stored credential **decrypts** — provable only by *using* it, since the API
   redacts credential values
4. a binary payload from the restored data directory is readable

**Readiness proves nothing about a restore.** The drill reported "boots ready
against the restored pair" while the scratch database was empty: n8n migrated a
blank database and reported ready. Assert restored *content* — the table count,
then the rows.

## Blast radius is a gate, not a note

A deployment whose backups share a credential with its live data and its
infrastructure state has no backups worth the name: the credential sitting on
the host can erase the thing that survives the host. Measured on the build that
produced this skill, the shared pair could list, write and **delete** in the
OpenTofu state bucket and delete backup sets.

The instructive part is the asymmetry that shipped first. The package enforced
bucket separation with two hard validator rules — backups may not share a
bucket with state or live data — while saying nothing at all about credentials.
A helper that answered "is the backup credential scoped?" existed and was
called only from tests.

**Enforcing a security property on one axis while silently permitting the other
is worse than enforcing neither**, because the visible rule implies the
invisible one is handled too. The fix was not to forbid the shared credential —
a first converge may predate the scoped tokens — but to make it impossible to
reach by accident: refuse it unless desired state carries an explicit
`shared-accepted`, so the weak posture is a committed line visible in a diff,
and have the gate report `RISK` on every run rather than a quiet `skip`.

A skip reads as "not applicable". An accepted risk is not the same thing and
should not be spelled the same way.

### Managed buckets

On AWS with `n8n-storage-managed: true` the question this gate asks is
settled before the converge rather than during it: the storage stage mints
one IAM user, one bucket-scoped policy and one access key per bucket, and the
pairs reach the play in the subprocess environment only. There is no operator
credential to share, so the validator's sharing rule does not apply and
`r2-credential-sharing` is not required. Gate R2 still runs, in `split` mode,
and lists the Neon prefix with the backup pair from the host; a listing that
S3 permits fails the converge. The policy is what makes the pass expected.
The gate is what makes it evidence. Both ran on `n8n-aws` on 2026-09-11: the
gate passed in `split` mode, and the refusal underneath it was IAM's, read
on the host in both directions (`credential-isolation.txt`; `aws.md`).

**Post-apply drift is a gate worth having.** On that deployment the second
create reported exit 0 while a read-only `tofu plan` in the storage stage
still had two changes: the SSE rule the provider reads back differed from
the one declared, and every converge removed and re-added it
(`storage-plan-after-create-2.txt`). An apply's success is not a plan's
emptiness. The package has no drift gate in this stage; run the plan after
the second create, expect `No changes`, and treat anything else as a
finding, the way the `clickhouse` package's final drift gate does with
`-detailed-exitcode`.

The same review found that the gate as first shipped could never pass at all:
it read a controller variable from a host-side script (the catalogue entry
"The backup-scope gate reports `RISK` on every run"). A gate that reports one
outcome on every run is not measuring anything. Before trusting a gate, name
the input that would flip it, and flip it once.

## The three meta-rules

**A gate that is never invoked is worse than no gate.** Inheriting a package's
acceptance *step* does not inherit its *gates*: the step is typically the
operator-side half, and a downstream play must invoke its own. This build's
first fully green converge reported success in 614 ms with zero application
gates executed.

**Time the acceptance stage and disbelieve a fast pass.** A suite that finishes
faster than its own sleeps is not running. The real suite takes 26 seconds
because of a 20-second WAL settle.

**Gate end state, never task outcomes.** Every task can be green while two
containers have never started.
