---
name: package-k8s-red
description: Build and operate a two-node kubeadm Kubernetes cluster on DigitalOcean with Red, Flannel, DigitalOcean CCM, Flux, ExternalDNS, cert-manager, and acceptance.
license: MIT
---

# kubeadm Kubernetes on DigitalOcean

Read [references/configuration.md](references/configuration.md) before changing
desired state or running a lifecycle command.

## Safety

- Keep secrets out of `colors.yml`; use ignored `COLORS_PAR_*` exports.
- Never set `COLORS_PAR_PROFILE` and never edit generated `.colors/` files.
- Default to `build` and `create --dry-run`; real create/delete needs explicit
  authorization.
- Keep `compute-prevent-destroy: true`. Lift it for one authorized delete with
  `COLORS_PAR_COMPUTE_PREVENT_DESTROY=false`.
- Restrict `digitalocean-ssh-sources` and `digitalocean-api-sources`; do not use
  `0.0.0.0/0` for administrative access.
- Do not copy `/etc/kubernetes/admin.conf`. `./red kubectl` uses it over SSH.

## Commands

```sh
./red build
./red create --dry-run
./red create
./red kubectl get nodes
./red kubectl get pods -A
./red delete
```

A real lifecycle run requires Bun, OpenTofu, Ansible, and SSH. The provided
`devenv.nix` supplies them. Flux watches a public HTTPS repository and path.
Ensure that path contains the controller/config/application reconciliation
objects before provisioning.

Delete first prunes the application and waits for external-dns to withdraw
the application host's DNS records, asks Kubernetes to remove the ingress
LoadBalancer and waits for its service finalizer, then destroys only the
deployment-owned Droplets, firewalls, and VPC (retrying DigitalOcean's
"VPC with members" refusal while the droplets drain), and finally removes
the deployment's SSH keypair.

The deployment owns its SSH keypair (keygen mode: leave `digitalocean-ssh-keys`
out of `colors.yml`; the first real `create` generates `~/.ssh/<profile>`,
registers it at DigitalOcean and names it in the `~/.ssh/config` block that
`ssh <profile>` and `kubectl` use). Supplying `digitalocean-ssh-keys` — an id
or fingerprint already on the account, the value this package used to take as
`digitalocean-ssh-key-fingerprint`, which is now refused by name — opts out and
uses your own key untouched.

## Compute dependency

colors-compute supplies the control-plane and worker machines, shared network,
firewalls, SSH keys, and remote R2 or S3 state. The package requests Kubernetes
controller support from the library and includes the returned tasks. A
compatible provider addition requires only a dependency update in this package.
Provider settings and capability validation belong to the library.

The default uses DigitalOcean with a deployment-owned VPC. Supply the selected
provider's settings and operator source CIDRs in `colors.yml`. Ansible uses the
returned node addresses and users. Generated keys live at `~/.ssh/<profile>`.
External SSH access requires an explicit `ssh-private-key-path` for Ansible.
The local SSH config leaves identity selection to the operator in external mode.

The previous combined infrastructure state requires explicit migration.
Updating the launcher does not transfer state or recreate the existing cluster.

### Repeated deletion after compute retirement

A repeated `delete` with validated retired compute ownership resumes only the
local generated-file cleanup. It does not require removed SSH keys or contact
the former hosts, DNS, registry, or other application cloud resources. Failed
ownership inspection still stops deletion. Local cleanup preserves unrelated
files and is safe to repeat.
